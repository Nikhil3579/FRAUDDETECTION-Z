"""
main.py  (FastAPI serving layer)
-----------------------------------
This is what you actually deploy. It loads the SAVED pipeline (preprocessor
+ model bundled together by joblib) exactly once at startup, then exposes
a POST /predict endpoint.

Run locally with:
    uvicorn api.main:app --reload --port 8000

Then open http://127.0.0.1:8000/docs for the interactive Swagger UI.

Deploying:
- Any host that can run a Python/uvicorn process works (Render, Railway,
  AWS EC2/ECS, GCP Cloud Run, Azure App Service, a plain VM + nginx).
- For containerized deploys, see the Dockerfile included in this project.
"""

import json
import sys
import os

import joblib
import pandas as pd
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

# Make the sibling `src` package importable when running from project root
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src import config
from src.feature_engineering import prepare_features
from api.schemas import TransactionRequest, FraudPredictionResponse

app = FastAPI(
    title="Fraud Detection API",
    description="Serves fraud-probability predictions from a trained XGBoost pipeline.",
    version="1.0.0",
)

# Allow calls from any frontend during development. Lock this down
# (specific domains) before going to real production.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# ---- Load model ONCE at startup, not per-request (this is important for speed) ----
_model_pipeline = None
_threshold = 0.5


@app.on_event("startup")
def load_artifacts():
    global _model_pipeline, _threshold
    if not os.path.exists(config.FINAL_MODEL_PATH):
        raise RuntimeError(
            f"Model not found at {config.FINAL_MODEL_PATH}. "
            "Run `python -m src.train_final` first."
        )
    _model_pipeline = joblib.load(config.FINAL_MODEL_PATH)

    if os.path.exists(config.THRESHOLD_PATH):
        with open(config.THRESHOLD_PATH) as f:
            _threshold = json.load(f)["threshold"]
    print(f"Model loaded. Using decision threshold={_threshold}")


def _risk_level(proba: float) -> str:
    if proba < 0.3:
        return "LOW"
    if proba < 0.7:
        return "MEDIUM"
    return "HIGH"


@app.get("/")
def root():
    return {"status": "ok", "message": "Fraud Detection API is running. See /docs for usage."}


@app.get("/health")
def health():
    return {"status": "healthy", "model_loaded": _model_pipeline is not None}


@app.post("/predict", response_model=FraudPredictionResponse)
def predict(request: TransactionRequest):
    if _model_pipeline is None:
        raise HTTPException(status_code=503, detail="Model not loaded yet.")

    try:
        # Build a single-row DataFrame with the SAME raw column names
        # the training pipeline expects, then reuse the exact same
        # feature-engineering function used during training.
        raw_df = pd.DataFrame([request.dict()])
        features_df = prepare_features(raw_df)

        proba = float(_model_pipeline.predict_proba(features_df)[:, 1][0])
        is_fraud = proba >= _threshold

        return FraudPredictionResponse(
            fraud_probability=round(proba, 4),
            is_fraud=is_fraud,
            threshold_used=_threshold,
            risk_level=_risk_level(proba),
        )
    except Exception as e:
        # Never leak stack traces to API consumers in production;
        # this is intentionally verbose for local debugging only.
        raise HTTPException(status_code=400, detail=f"Prediction failed: {str(e)}")
